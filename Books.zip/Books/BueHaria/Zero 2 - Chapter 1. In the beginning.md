"Hey, Tony!" Joe's voice pierced through the helicopter's noise.

"Yeah?" I thought he was going to ask me to join him for a drink later.

"Wanna grab a drink after this shift?"

"Nah, I'm good," I replied, knowing I had some things to take care of at home.

It was a Saturday night when we received a call. A house had imploded, trapping people inside. I couldn't understand why they had requested a helicopter, but as we approached the scene, I could see the flickering flames. The house was massive, with at least two underground floors. The ground crew had been struggling to gain entry, reporting that they could hear a girl calling for help. With the helicopter, we could use the lift and easily reach the open space in the middle of the second underground floor. I lowered Joe using the double lift, watching as he disappeared under the roof. Suddenly, there was another explosion! The blast damaged the tail rotor, and I was forced to make an emergency landing amidst the rubble. I didn't think I would make it, but somehow I did. With the chopper's noise gone, I could now clearly hear the desperate cries of the girl. Navigating through the debris, I followed her voice until I found her trapped beneath a fallen machine. Straining to lift the heavy object, I felt a searing pain in my back as another machine crashed down upon me.

Waking up to the familiar hospital smell on a bed with white sheets and turquoise curtains. Only this time, I was the patient. 

"I wonder if Bob was the one who rescued me since he was also on duty that night" I thought to myself "Something fell on my back, so can I feel my toes?" I wiggled my toes "thank goodness!"  
Suddenly my whole body was in extreme pain! It felt like blades of electricity cutting through my whole body from head to toe . 
"Oh no is this paralysis?" I thought to myself. Then I lost consciousness.

***

I'm gaining consciousness again. I feel a concrete floor beneath me and the sun's warmth shining on me. I open my eyes and I see the sunrise and a beautiful tropical jungle before me. 
"Can I move?" I wonder. Remembering the excruciating pain after wiggling my toes previously, I somewhat cautiously just concentrate on where my body is getting nerve signals from. I can feel concrete beneath my body. I look down. I'm wearing a white t-shirt and blue jeans. No shoes. I slowly move my right hand and wait. No shocking pain. "Good" I think to myself. I slowly move my left foot and wait. No pain. I look up at the ceiling. It's rough concrete. I look around. Three walls surround me with the open jungle in front of me. Still half asleep, I move out to the jungle walking straight into a glass wall. PAIN! I fall down to the floor and just lie there. I look around again. There is a splat of blood seemingly hanging in the air nearby. Then I see the previously unnoticed sunlight reflecting off the thick glass wall. It is thick glass. With a splat of blood in the middle. And my nose is bleeding now. I sit up, lean forward and pinch my nose, holding it there to stop the bleeding.  
"What on Earth is going on?"

After the bleeding has stopped I get up slowly and start exploring what little there is to explore in this room. There are no doors. In the corner to the right I notice a small slit about a foot wide and three inches high. Bending down to look through it I notice it's closed up with thick metal on the outside. 

"How did I get in here? Who did this to me? And why?"

As a search and rescue pilot, I've been helping people in need of medical attention and now I need to be searched for and rescued. But there's no one in sight. 

I spend the rest of the day calling for help. Nothing. As night falls I fall asleep tired and hoarse.

I wake up to the sound of a metallic clunk coming from the hole in the wall. There's a paper plate with a slice of brown bread and a styrofoam cup with water. Hungrily I gulp down the bread and water. 

I spend the rest of the day calling and fall asleep tired and hoarse. Nothing.

The next morning, there's bread and water again.

Days go by.

Everything's a blur. How long have I been here? I’ve lost count of the days.

The glass seems to be a bit thicker than a normal window pane. If I had a tool maybe I could break it. I have nothing. I never see or hear whoever gives me the food. I’ve tried staying awake to see them but then I just don’t get any food. I’ve tried everything else. Screaming and shouting and calling for help for days just made me hoarse.

Waiting for someone to rescue me is futile. Today is the day. Today I will break through the glass and face the pain. What if the glass gorges my eyes out? Or what if it cuts an artery and I bleed to death? Death feels rather welcome right now, but not when accompanied by excruciating pain. I am alive. I have everything I need. Food, water, clothes, protection from the elements… Yeah right.

Today is the day…. It's getting late. I’ll have to try tomorrow….

Another beautiful sunrise. Another two slices of bread and water. Another day goes by into nothingness.

The sun has risen again, but it’s overcast today. Winter may be on the way. I don’t know. I don’t know anything about survival. If I ever manage to break through the glass how will I survive? I haven’t seen any signs of human activity other than the food supplies.

A couple of days later the sun is bright and warm again. At noon I notice the sun is very high so I figure winter is still far off. Tomorrow.

Another sunrise. Another day. I feel I’m getting weaker. I must do something before it’s too late. I HAVE to break through that window. But just the thought of that glass cutting through my skin scares me. But I have to do this. I have to LIVE or die trying!

I need to make sure this works. I think the weakest place in the glass would be in the center. I will have to run from the back wall. It will only be a couple of steps of space to run. I’m not even sure if I can run anymore. I move to the back wall and stand with my back against the wall.

I take one last look at the empty concrete room. I take one last look at the empty paper plate and styrofoam cup. I wish I could armour plate myself against the glass. Wait a moment - the plate!. I move to the side and pick up the plate. There’s not even a crumb since I picked each crumb off as usual. I have to protect myself. I don’t want to bleed to death here. I move back to the center of the rear wall.

I’m standing with my back to the wall. I’m hunched forward with my right arm around my head, elbow jutting forward toward the glass. My left hand holding the paper plate against the elbow for protection against the glass. Here goes! I run 3 steps before hitting the glass. Pain shoots through my elbow. I black out.

Waking up, I hear the sound of voices from far off. I have to move quickly. I gather all my energy, get up and start running. Pain shoots through my left leg but I have to keep going. I can hardly see from all the pain but I keep moving. Up ahead I see bushes that could hide me. I run into them, but the twigs scratch my wounds and cause me to writhe in pain. Suddenly my left foot slips and I start sliding down. It’s a cliff. I can’t see how far because of the bushes. I land with a splash in a small river and as I open my eyes I see I’m almost at the edge of a waterfall. With no time for my weakened body to react I fell down the waterfall about 4 meters. I black out again.

***

As I come to, I can feel cold steel on my back. I can smell chemicals. Not the kind you’d find in a hospital, but rather in a science laboratory. I open my eyes. I see an old professor with messy white wisps of hair wearing a lab-coat and glasses.

“This is interesting,” the professor ponders, “How did you get here?”

“What?” I answer bewildered, “You didn’t bring me here?”

“No,” he answers calmly, “You-” he checks himself, “ Hi, I’m Professor Albert Simmons.” He stretches out his hand to shake my hand in greeting.

“I’m Tony,” I answer and sit up with surprising ease, “Hey, I have no pain at all!”

“Hmm, interesting,” the prof says thoughtfully, “Where were you before you appeared here?”

“Appeared?” I’m confused “I-” I black out again.

…

I woke up. I'm not in the concrete room nor a lab. I'm in bed. I smell hospital smells. I check to feel for any pain from the gunshots, but there's no pain, so I must have been here for a long time.

I open my eyes to see someone sitting next to my hospital bed.  
It's another patient. A girl of mixed race with well kept dreadlocks. She's holding a crutch and her leg is in a cast. A drip stand next to her is linked to a drip in her hand.

"Hi!" She said, trying to smile. She winces. I can see she's in pain. She looked worried. Her voice sounded somewhat familiar.

"Are you the girl I tried to save?" I asked.

"Yeah. Thanks for crushing my leg to save my life" she said, managing a wry grin.

"It must have been very serious if you are still in a cast and on drips after all this time" I said, confused at what seemed to have been a year that passed. 
"Wait, how come I'm back at the same hospital? And are you stalking me or something? What's going on here?" I demanded. Everything was getting really confusing.

"You rescued me three days ago. And we both haven't left the hospital since." She stated, matter of factly. Looking to see my reaction.

"What? So the glass and gunshot wounds and falling off the waterfall, were all a dream? That was way too real to be a dream!" I thought aloud.  
Maybe I shouldn't have said that. I’m still a bit edgy expecting someone to jump through a window with machine guns and start shooting at me anytime.

"Waterfall huh?" She grinned wryly. And then she leaned forward and looked at me straight in the eye and said "That means we really need to talk. But not here. I expect you'll be released from the hospital quickly, but I'll still be here for a while"

"I thought I was almost paralyzed from heavy machinery falling onto my back and you think I'll be out soon? And what happened to the bullet wounds...?" This woman was starting to sound really crazy to me. Or maybe I was starting to lose my mind. 

"Just come and see me whenever you are ready. Just ask for Denise Williams in Ward 3. If I'm released, I'm mostly at the Faculty of Science, Nanotechnology Department. I'm doing my Masters there." She took a hold of the crutch, wincing while pulling herself up and left the room. 
