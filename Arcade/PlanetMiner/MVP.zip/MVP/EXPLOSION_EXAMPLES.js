// QUICK REFERENCE: Planet Explosion Functions
// ============================================

// Example 1: Explode the first planet
explodeCelestialBody(solarSystemData[0]);

// Example 2: Explode the third planet
explodeCelestialBody(solarSystemData[2]);

// Example 3: Explode the first moon of the first planet
explodeCelestialBody(solarSystemData[0].moons[0]);

// Example 4: Explode all moons of a planet
solarSystemData[0].moons.forEach(moon => {
    explodeCelestialBody(moon);
});

// Example 5: Only remove visuals without explosion effects
removeCelestialBodyVisuals(solarSystemData[1]);

// Example 6: Trigger explosion on keypress (add to keydown event listener)
// In the keydown event listener section, add:
/*
if (event.key === 'x' && event.shiftKey) {
    // Shift+X: Explode current planet/moon
    if (currentSystemIndex !== undefined && currentBodyIndex !== undefined) {
        const currentSystem = solarSystemData[currentSystemIndex];
        if (currentBodyIndex === 0) {
            // Exploding the planet
            explodeCelestialBody(currentSystem);
        } else {
            // Exploding a moon
            const moonIndex = currentBodyIndex - 1;
            explodeCelestialBody(currentSystem.moons[moonIndex]);
        }
    }
}
*/

// NOTES:
// ------
// 1. The black hole bubble remains after explosion
// 2. Rings and other moons are NOT affected
// 3. The rocket is safe from explosions
// 4. Gravitational effects continue (bubble provides gravity)
// 5. You can still orbit and land on the bubble after explosion
