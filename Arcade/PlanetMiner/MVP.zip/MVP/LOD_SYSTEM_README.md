# LOD (Level of Detail) System for Voxel Terrains

## Overview
The LOD system dynamically adjusts the visual detail of planets and moons based on gameplay context, significantly improving performance while maintaining visual quality where it matters most.

## LOD Levels

### High LOD - Full Voxel Terrain
- **Appearance**: Full marching cubes voxel terrain with vertex colors
- **Performance**: Most expensive (complex geometry)
- **Used for**:
  - The planet/moon system where the character is currently located
  - The planet/moon system closest to the rocket
  - Any planet/moon system that the rocket's trajectory line intersects

### Medium LOD - Textured Sphere
- **Appearance**: Smooth sphere with procedurally generated texture matching the color theme
- **Performance**: Medium cost (simpler geometry, texture lookup)
- **Used for**: All other visible planets/moons not meeting high or low LOD criteria

### Low LOD - Icosahedron
- **Appearance**: Simple geometric icosahedron with flat shading and solid color
- **Performance**: Cheapest (minimal geometry, no textures)
- **Used for**: Planets/moons on the opposite side of the sun from the camera (when in character mode)

## Implementation Details

### Module: `pLODSystem.js`

#### Key Components:

1. **LODManager Class**
   - Manages LOD state for all celestial bodies
   - Caches mesh instances to avoid regeneration
   - Determines appropriate LOD level based on context
   - Handles mesh swapping when LOD level changes

2. **LOD Determination Logic**
   - Checks character's current system (HIGH)
   - Checks rocket's proximity (HIGH)
   - Checks trajectory intersection (HIGH)
   - Checks sun occlusion in character mode (LOW)
   - Everything else gets MEDIUM

3. **Mesh Caching**
   - Each LOD level for each body is cached after first creation
   - Reuses existing high LOD meshes created during initialization
   - Prevents expensive terrain regeneration

### Integration in `pMain.js`

1. **Initialization**
   - LODManager created during system setup
   - Initial LOD set after character positioning
   - All bodies start with appropriate LOD based on starting position

2. **Update Loop (Priority 2.5)**
   - Runs after orbital updates, before visual effects
   - Builds LOD context with:
     - Character position and system index
     - Rocket position and closest system
     - Trajectory intersections
     - Camera position
     - Sun position
   - Updates all bodies' LOD based on context

3. **Debug Display**
   - Shows LOD statistics when debug mode is active
   - Format: `LOD: High=X Med=Y Low=Z`

## Performance Benefits

1. **Reduced Polygon Count**
   - High LOD voxel terrains only where player can see detail
   - Medium LOD spheres for distant observation
   - Low LOD icosahedrons for barely visible bodies

2. **Intelligent Switching**
   - Anticipates where player will go (trajectory intersection)
   - Maintains quality for active gameplay areas
   - Reduces detail for occluded bodies

3. **Smart Caching**
   - Reuses meshes instead of regenerating
   - Keeps high LOD terrain in memory for quick switching
   - Minimal overhead for LOD transitions

## Usage

The LOD system works automatically once initialized. No player interaction required.

### For Developers:

To adjust LOD behavior, modify:
- `determineRequiredLOD()` - Change LOD selection logic
- LOD creation methods - Adjust visual quality vs. performance trade-offs
- Update frequency - Change priority in animation loop if needed

### Debug Info:

Enable debug mode (when implemented) to see:
- Current LOD distribution across all bodies
- LOD level of specific bodies
- Performance metrics

## Future Enhancements

Potential improvements:
1. Distance-based LOD transitions for smoother changes
2. Hysteresis to prevent rapid LOD switching
3. LOD level for rings and atmospheres
4. Configurable LOD distances/thresholds
5. LOD preview mode for development
