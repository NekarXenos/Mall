# Migration Checklist: Old pMain.js → Refactored pMain.js

## ✅ Step-by-Step Migration Guide

### Step 1: Backup Current Code
```powershell
# Create backup
Copy-Item src\pMain.js src\pMain_BACKUP_$(Get-Date -Format 'yyyyMMdd_HHmmss').js

# Or simple backup
Copy-Item src\pMain.js src\pMain_OLD.js
```

### Step 2: Review the Changes
- [x] Read `DUPLICATION_ANALYSIS.md`
- [x] Compare `pMain.js` vs `pMain_REFACTORED.js`
- [x] Understand the new `PlanetMinerGame` class structure

### Step 3: Replace Main File
```powershell
# Replace with refactored version
Copy-Item src\pMain_REFACTORED.js src\pMain.js
```

### Step 4: Test Basic Functionality
Open `planetsMVPmodules.html` in browser and test:
- [ ] Game loads without errors
- [ ] Solar system generates
- [ ] Character spawns on first planet
- [ ] Camera modes work (V key)
- [ ] Free camera zoom works (Z key)
- [ ] Movement works (WASD)
- [ ] Jetpack toggle works (J key)
- [ ] Teleport works (T/Y keys)

### Step 5: Test Advanced Features
- [ ] Rocket mode switch (F key)
- [ ] Rocket controls work
- [ ] Mouse look works in first/third person
- [ ] Explosions work
- [ ] Black hole system works
- [ ] UI updates properly

### Step 6: Check Console for Errors
Open browser DevTools (F12) and check:
- [ ] No import errors
- [ ] No undefined variable errors
- [ ] No "is not a function" errors

---

## 🐛 Common Issues & Fixes

### Issue: "Cannot read property 'keys' of undefined"
**Cause:** InputManager not properly initialized  
**Fix:** Check that `this.inputManager.setupEventListeners()` is called

### Issue: "getRocketWorldPosition is not a function"
**Cause:** RocketSystem not created yet  
**Fix:** Ensure rocket is created: `rocketSystem.createRocket(initialPos, planetGroup)`

### Issue: "Camera not updating"
**Cause:** CameraController.update() not being called  
**Fix:** Check animation loop priority 1 callback

### Issue: "Character not visible"
**Cause:** Character not added to scene  
**Fix:** Ensure `scene.add(this.pivot)` is called after character setup

### Issue: "Black screen"
**Cause:** Render not being called  
**Fix:** Check animation loop priority 4 callback with proper camera

---

## 📝 TODO: Features to Complete

### High Priority
- [ ] **Create Rocket:** Add `rocketSystem.createRocket()` call in init()
- [ ] **Add Character to Scene:** `scene.add(this.pivot)` after setupCharacter()
- [ ] **Wire up 'R' Key:** Connect to explosion system
- [ ] **Update Orbits:** Add orbital motion in animation loop

### Medium Priority  
- [ ] **Animate Sun Texture:** Update sun canvas texture each frame
- [ ] **Quest Complete:** Implement system collapse trigger
- [ ] **Landing System:** Complete rocket landing on bodies
- [ ] **Tractor Beam:** Verify tractor beam functionality

### Low Priority
- [ ] **Debug Mode:** Add debug axis visualization (D key)
- [ ] **Performance Stats:** Add FPS counter
- [ ] **Save/Load:** Implement game state persistence

---

## 🎯 Quick Wins

These are easy additions that give immediate results:

### 1. Add Rocket Creation
```javascript
// In init() method, after setting up character:
const firstPlanet = this.teleportLocations[0][0];
const rocketPos = new THREE.Vector3();
firstPlanet.object.getWorldPosition(rocketPos);
rocketPos.add(new THREE.Vector3(0, firstPlanet.radius + 15, 0));

const { rocketObject, rocketPivot, rocketPlume } = 
    this.rocketSystem.createRocket(rocketPos, firstPlanet.parentGroup);
```

### 2. Add Character to Scene
```javascript
// In init() method, after setupCharacter():
this.sceneSetup.scene.add(this.pivot);
```

### 3. Add Orbital Motion
```javascript
// In setupAnimationLoop(), add new callback:
this.animLoopManager.onUpdate((delta) => {
    // Update planet orbits
    this.solarSystemData.forEach(planetData => {
        planetData.orbitAngle += planetData.orbitSpeed * delta;
        const x = Math.cos(planetData.orbitAngle) * planetData.orbitRadius;
        const z = Math.sin(planetData.orbitAngle) * planetData.orbitRadius;
        planetData.planetGroup.position.set(x, 0, z);
        
        // Update moon orbits
        planetData.moons.forEach(moonData => {
            moonData.orbitAngle += moonData.orbitSpeed * delta;
            const mx = Math.cos(moonData.orbitAngle) * moonData.orbitRadius;
            const mz = Math.sin(moonData.orbitAngle) * moonData.orbitRadius;
            moonData.moonGroup.position.set(mx, 0, mz);
        });
    });
}, 0);
```

---

## 🔄 Rollback Plan

If something goes wrong:

```powershell
# Restore from backup
Copy-Item src\pMain_OLD.js src\pMain.js

# Or restore from timestamped backup
Copy-Item src\pMain_BACKUP_20250124_*.js src\pMain.js
```

---

## 📊 Success Metrics

You'll know the refactoring is successful when:

- ✅ Code is 60%+ shorter
- ✅ No duplicate functions between pMain.js and modules
- ✅ All features work identically to before
- ✅ Console shows no errors
- ✅ Each system is properly encapsulated
- ✅ Easy to find and modify specific features

---

## 🎉 Completion

Once all checkboxes are complete, you have:
- ✅ Fully modularized game code
- ✅ Clean separation of concerns
- ✅ Easy to maintain and extend
- ✅ Professional code architecture

**Congratulations!** Your refactoring is complete! 🚀

---

## 📞 Need Help?

If you encounter issues:
1. Check console for error messages
2. Review `DUPLICATION_ANALYSIS.md` for module usage
3. Compare with `pMain_OLD.js` to see what changed
4. Test each module independently

**Remember:** The refactored code does the same thing, just more cleanly!
