# Phase 6: Integration Guide

## Overview
This guide outlines the systematic integration of all 11 modules into `pMain.js`.

## Current Status
- ✅ All 11 modules created and documented
- ✅ Import statements added to pMain.js
- 🔄 System initialization started (needs completion)
- ❌ Old code removal pending
- ❌ Function replacements pending
- ❌ Testing pending

## Integration Steps

### Step 1: Remove Old Rocket Creation Code ✅ NEEDS ATTENTION
**Location**: Lines 266-419 in pMain.js (inside `if (pIndex === 0)` block)

**Code to Remove**:
```javascript
// --- Rocket ---
const rocket = new THREE.Group();
// ... all rocket mesh creation code
// ... direction arrow creation
// ... debug axes creation
```

**Why**: RocketSystem now creates the rocket via `createRocket()` method

### Step 2: Remove Old Rocket State Variables ✅ PARTIALLY DONE
**Location**: Lines 60-95 in pMain.js

**Already Removed**:
- ✅ `rocketObject`, `rocketPivot`, `isInRocket`
- ✅ `rocketVelocity`, `rocketLaunchPlanet`, `rocketPlume`
- ✅ `trajectoryLine`, `rocketYaw`
- ✅ All launch assist variables
- ✅ All tractor beam variables

**Kept**:
- `debugMode`, `debugAxesGroup` (not rocket-specific)

### Step 3: Initialize Systems ✅ IN PROGRESS
**Location**: Before animation loop (~line 2200)

**Current Code** (needs adjustment):
```javascript
// Initialize UI Manager
const uiManager = new UIManager(infoElement);

// Initialize Visual Effects Manager
const vfxManager = new VisualEffectsManager(scene);

// Initialize Sun Animation Manager  
const sunAnimManager = new SunAnimationManager(scene, sun, corona, sunLight, camera);

// Initialize Rocket System
const rocketSystem = new RocketSystem(scene, solarSystemData, sun, infoElement);

// Create the rocket at the first planet
rocketSystem.createRocket(rocketSpawnPos, firstPlanetData.planetGroup);

// Get references for backward compatibility
const rocketObject = rocketSystem.rocketObject;
const rocketPivot = rocketSystem.rocketPivot;
// ... etc
```

**Issue**: Variable name conflicts. Need to remove old declarations first.

### Step 4: Replace Rocket Helper Functions
**Functions to Remove** (use rocketSystem methods instead):
- `getRocketWorldQuat()` → `rocketSystem.getRocketWorldQuat()`
- `getRocketForwardWS()` → `rocketSystem.getRocketForwardWS()`
- `getRocketRightWS()` → `rocketSystem.getRocketRightWS()`
- `getRocketLeftWS()` → `rocketSystem.getRocketLeftWS()`

### Step 5: Replace Rocket Update Logic
**Location**: Inside `animate()` function

**Current Code Pattern**:
```javascript
if (isInRocket) {
    // Complex rocket physics code
    // updateRocket() calls
    // trajectory prediction
}
```

**Replace With**:
```javascript
if (rocketSystem.isInRocket) {
    rocketSystem.update(delta, inputSystem, characterController, cameraController);
}
```

### Step 6: Replace Mode Switching Functions
**Functions to Replace**:

1. **switchToRocket()**
```javascript
// Old:
function switchToRocket() { /* complex code */ }

// New:
rocketSystem.enterRocket(character, characterController);
```

2. **switchToCharacter()**
```javascript
// Old:
function switchToCharacter() { /* complex code */ }

// New:
rocketSystem.exitRocket(character, characterController);
```

### Step 7: Replace Tractor Beam Logic
**Functions to Replace**:
- Tractor beam toggle → `rocketSystem.toggleTractorBeam()`
- Tractor beam update → `rocketSystem.updateTractorBeam(delta)`

### Step 8: Replace UI Updates
**Pattern to Replace**:
```javascript
// Old:
infoElement.textContent = `Speed: ${speed.toFixed(1)} u/s...`;

// New:
uiManager.updateRocketFlying(rocketData);
```

**UI Update Locations**:
- Character mode: ~15 instances
- Rocket mode: ~10 instances  
- Quest/special events: ~5 instances

### Step 9: Replace Visual Effects
**Code to Replace**:

1. **Explosion Creation**
```javascript
// Old:
createExplosion(position, count);
activeExplosions.push(...);

// New:
vfxManager.createExplosion(position, count);
```

2. **Explosion Updates**
```javascript
// Old:  
for (let i = activeExplosions.length - 1; i >= 0; i--) {
    // complex update logic
}

// New:
vfxManager.updateExplosions(delta);
```

3. **Black Hole Bubble Updates**
```javascript
// Old:
allBlackHoleBubbles.forEach(bubble => {
    // update logic
});

// New:
vfxManager.updateBlackHoleBubbles(allBlackHoleBubbles);
```

### Step 10: Replace Sun Collapse Logic
**Code to Replace**:
```javascript
// Old:
if (sunCollapsing) {
    sunCollapseTimer += delta;
    // complex animation code
}

// New:
if (questComplete && !sunAnimManager.isCollapsing()) {
    sunAnimManager.startCollapse();
}
sunAnimManager.update(delta);
```

### Step 11: Replace Animation Loop
**Current Structure**:
```javascript
function animate() {
    const delta = clock.getDelta();
    
    // 300+ lines of update logic
    
    renderer.render(scene, camera);
    requestAnimationFrame(animate);
}
```

**New Structure**:
```javascript
function animate() {
    const delta = clock.getDelta();
    
    // Register update callbacks
    animLoopManager.addCallback('sunAnimation', () => sunAnimManager.update(delta));
    animLoopManager.addCallback('vfx', () => vfxManager.update(delta));
    animLoopManager.addCallback('rocketSystem', () => {
        if (rocketSystem.isInRocket) {
            rocketSystem.update(delta, inputSystem, characterController, cameraController);
        }
    });
    
    // Execute all updates
    animLoopManager.executeCallbacks();
    
    // Render
    renderer.render(scene, camera);
    requestAnimationFrame(animate);
}
```

## Variable Mapping

### Rocket System
| Old Variable | New Access Path |
|--------------|----------------|
| `rocketObject` | `rocketSystem.rocketObject` |
| `rocketPivot` | `rocketSystem.rocketPivot` |
| `rocketPlume` | `rocketSystem.rocketPlume` |
| `isInRocket` | `rocketSystem.isInRocket` |
| `rocketVelocity` | `rocketSystem.rocketVelocity` |
| `rocketYaw` | `rocketSystem.rocketYaw` |
| `tractorBeamActive` | `rocketSystem.tractorBeamActive` |
| `trajectoryLine` | `rocketSystem.trajectoryLine` |

### UI System
| Old Pattern | New Method |
|-------------|-----------|
| `infoElement.textContent = ...` | `uiManager.updateCharacterInfo(data)` |
| Direct text formatting | `uiManager.updateRocketFlying(data)` |
| Message handling | `uiManager.showMessage(text, duration)` |

### Visual Effects
| Old Variable | New Access Path |
|--------------|----------------|
| `activeExplosions` | `vfxManager.activeExplosions` |
| `createExplosion()` | `vfxManager.createExplosion()` |

### Sun Animation
| Old Variable | New Access Path |
|--------------|----------------|
| `sunCollapsing` | `sunAnimManager.isCollapsing()` |
| `sunCollapseTimer` | Internal to manager |
| `blackHoleActive` | `sunAnimManager.isBlackHoleActive()` |

## Testing Checklist

After integration, test all features:

### Character Mode
- [ ] Walking/running on planets
- [ ] Jetpack thrust and fuel
- [ ] Jumping
- [ ] Teleportation
- [ ] Planet transitions
- [ ] UI displays correctly

### Rocket Mode  
- [ ] Enter/exit rocket (E key)
- [ ] Rocket flight controls (WASD)
- [ ] Rocket physics and gravity
- [ ] Trajectory prediction line
- [ ] Landing on planets/moons
- [ ] Launch assist
- [ ] Tractor beam autopilot (T key)
- [ ] UI displays speed, distance, target

### Visual Effects
- [ ] Explosions trigger on planet destruction
- [ ] Black hole bubbles animate
- [ ] Sun collapse animation
- [ ] Black hole formation
- [ ] Corona effects

### Camera
- [ ] Follow cam in character mode
- [ ] Chase cam in rocket mode
- [ ] Zoom in/out (mouse wheel)
- [ ] Debug cam (C key)

### Special Features
- [ ] Quest completion (reach distant planet)
- [ ] Sun collapse triggers
- [ ] Black hole gravity pulls rocket
- [ ] Debug mode toggle (D key)

## Known Issues

1. **Rocket creation timing**: Rocket must be created AFTER solar system generation completes
2. **Camera references**: Some systems need camera - passed correctly?
3. **Input system**: Must be instantiated before rocket/character updates
4. **Circular dependencies**: Watch for module import cycles

## Next Steps

1. ✅ Complete rocket code removal from pMain.js
2. ✅ Finalize system initialization
3. ❌ Replace all rocket function calls with rocketSystem methods
4. ❌ Replace all UI updates with uiManager calls
5. ❌ Replace all VFX code with vfxManager calls
6. ❌ Replace sun animation with sunAnimManager
7. ❌ Test each system individually
8. ❌ Test integrated game
9. ❌ Performance testing
10. ❌ Create final integration summary document

## References
- [Rocket System Extraction](./ROCKET_SYSTEM_EXTRACTION.md)
- [Rocket Integration Guide](./ROCKET_INTEGRATION_GUIDE.md)
- [UI & Rendering Extraction](./UI_RENDERING_EXTRACTION.md)
- [Modularization Complete Summary](./MODULARIZATION_COMPLETE.md)
