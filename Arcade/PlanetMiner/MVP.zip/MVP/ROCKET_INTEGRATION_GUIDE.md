# Integration Guide: Rocket System Module

## Quick Reference for Updating pMain.js

### 1. Add Import Statement
Add to the top of `pMain.js` with other imports:

```javascript
import { RocketSystem } from './pRocketSystem.js';
```

### 2. Replace Rocket State Variables
**Remove these variables** (around line 56-92):
```javascript
// OLD CODE TO REMOVE:
let rocketObject = null;
let rocketPivot = null;
let isInRocket = false;
const rocketVelocity = new THREE.Vector3();
let rocketLaunchPlanet = null;
let rocketPlume = null;
let trajectoryLine = null;
let rocketYaw = 0;
let trajUpdateTimer = 0;
let launchAssistActive = false;
let launchAssistBody = null;
// ... all other launch assist and tractor beam variables
```

**Replace with**:
```javascript
// NEW CODE:
const rocketSystem = new RocketSystem(scene, solarSystemData, sun, infoElement);
```

### 3. Replace Rocket Creation Code
**Remove** rocket creation code (around line 296-400):
```javascript
// OLD CODE TO REMOVE:
// --- Rocket ---
const rocket = new THREE.Group();
// ... entire rocket creation section
```

**Replace with**:
```javascript
// NEW CODE:
// Create rocket at initial position on first planet
const planetWorldPos = new THREE.Vector3(
    solarSystemData[0].orbitRadius * Math.cos(solarSystemData[0].orbitAngle),
    0,
    solarSystemData[0].orbitRadius * Math.sin(solarSystemData[0].orbitAngle)
);
const radial = planetWorldPos.clone().normalize();
const spawnOffset = solarSystemData[0].effectiveRadius + 5;
const rocketInitialPos = planetWorldPos.clone().add(radial.multiplyScalar(spawnOffset));

const { rocketObject, rocketPivot, rocketPlume } = rocketSystem.createRocket(
    rocketInitialPos,
    solarSystemData[0].planetGroup
);
```

### 4. Replace switchToRocket Function
**Remove** (around line 689):
```javascript
// OLD CODE TO REMOVE:
function switchToRocket() {
    isInRocket = true;
    // ...
}
```

**Replace with**:
```javascript
// NEW CODE:
function switchToRocket() {
    rocketSystem.switchToRocket();
}
```

### 5. Replace switchToCharacter Function
**Update** (around line 707):
```javascript
// OLD CODE:
function switchToCharacter() {
    isInRocket = false;
    // ...
}

// NEW CODE:
function switchToCharacter() {
    rocketSystem.switchToCharacter();
    characterController.updateInfoText();
    if (cameraMode === 'free') {
        mouseLookEnabled = false;
        document.exitPointerLock();
    }
}
```

### 6. Replace updateTrajectory Function
**Remove** (around line 1474):
```javascript
// OLD CODE TO REMOVE:
function updateTrajectory(delta) {
    // ... entire function
}
```

**Replace with**:
```javascript
// NEW CODE - Call directly:
// rocketSystem.updateTrajectory(delta, keys);
```

### 7. Replace updateRocket Function
**Remove** (around line 1529-2150):
```javascript
// OLD CODE TO REMOVE:
function updateRocket(delta) {
    // ... entire massive function
}
```

**Replace with**:
```javascript
// NEW CODE - Call directly:
// rocketSystem.updateRocket(delta, keys);
```

### 8. Update Main Update Loop
**Find** the update loop (around line 2200+):
```javascript
// OLD CODE:
if (isInRocket) {
    trajUpdateTimer += delta;
    if (trajUpdateTimer > 0.1) {
        updateTrajectory(delta);
        trajUpdateTimer = 0;
    }
    updateRocket(delta);
}

// NEW CODE:
if (rocketSystem.isInRocket) {
    rocketSystem.trajUpdateTimer += delta;
    if (rocketSystem.trajUpdateTimer > 0.1) {
        rocketSystem.updateTrajectory(delta, keys);
        rocketSystem.trajUpdateTimer = 0;
    }
    rocketSystem.updateRocket(delta, keys);
}
```

### 9. Update Key Handlers

**Find 'F' key handler** for switching modes:
```javascript
// OLD CODE:
if (key === 'F') {
    if (isInRocket) {
        switchToCharacter();
    } else {
        switchToRocket();
    }
}

// NEW CODE:
if (key === 'F') {
    if (rocketSystem.isInRocket) {
        switchToCharacter();
    } else {
        switchToRocket();
    }
}
```

**Find 'O' key handler** for tractor beam:
```javascript
// OLD CODE:
if (key === 'O' && isInRocket) {
    // ... old tractor beam toggle code
}

// NEW CODE:
if (key === 'O' && rocketSystem.isInRocket) {
    const rocketPos = rocketSystem.getRocketWorldPosition();
    rocketSystem.toggleTractorBeam(rocketPos);
}
```

### 10. Update Camera Updates
**Find** camera update code that references rocket:
```javascript
// OLD CODE:
if (isInRocket && rocketObject) {
    const rocketWorldPos = new THREE.Vector3();
    rocketObject.getWorldPosition(rocketWorldPos);
    // ...
}

// NEW CODE:
if (rocketSystem.isInRocket && rocketSystem.rocketObject) {
    const rocketWorldPos = rocketSystem.getRocketWorldPosition();
    // ...
}
```

### 11. Update Explosion Handler (R key)
**Find** explosion code that checks isInRocket:
```javascript
// OLD CODE:
if (key === 'R' && isInRocket) {
    // ... explosion code
}

// NEW CODE:
if (key === 'R' && rocketSystem.isInRocket) {
    // ... explosion code
}
```

## Removed Helper Functions

These functions are now methods of RocketSystem and should be **removed** from pMain.js:
- `getRocketWorldQuat()`
- `getRocketForwardWS()`
- `getRocketRightWS()`
- `getRocketLeftWS()`
- `updateTrajectory(delta)`
- `updateRocket(delta)`

## Property Access Changes

### Direct Property Access
When you need to access rocket properties directly:

| Old Code | New Code |
|----------|----------|
| `rocketObject` | `rocketSystem.rocketObject` |
| `rocketPivot` | `rocketSystem.rocketPivot` |
| `rocketPlume` | `rocketSystem.rocketPlume` |
| `isInRocket` | `rocketSystem.isInRocket` |
| `rocketVelocity` | `rocketSystem.rocketVelocity` |
| `rocketYaw` | `rocketSystem.rocketYaw` |
| `tractorBeamActive` | `rocketSystem.tractorBeamActive` |

### Method Calls
Use these methods instead of direct manipulation:

| Old Code | New Code |
|----------|----------|
| `rocketObject.getWorldPosition(pos)` | `rocketSystem.getRocketWorldPosition()` |
| Check if landed | `rocketSystem.isLanded()` |
| Toggle tractor beam | `rocketSystem.toggleTractorBeam(pos)` |

## Testing Checklist

After integration, test these features:

- [ ] Rocket appears at initial position
- [ ] Can switch between character and rocket (F key)
- [ ] Rocket responds to thrust (W key)
- [ ] Boost mode works (Shift+W)
- [ ] Yaw control works (A/D keys)
- [ ] RCS strafe works (Q/E keys)
- [ ] Brake works (X key)
- [ ] Orbital sync works (Shift+X)
- [ ] Takeoff from landed position works
- [ ] Launch assist activates on takeoff
- [ ] Collision detection works (forced landing)
- [ ] Tractor beam activation works (O key)
- [ ] Tractor beam approach mode works
- [ ] Tractor beam landing mode works
- [ ] Auto-landing completes successfully
- [ ] Trajectory line displays correctly
- [ ] Plume colors change based on mode
- [ ] Camera tracks rocket correctly
- [ ] Debug axes work (if enabled)

## Common Issues and Solutions

### Issue: "rocketSystem is not defined"
**Solution**: Make sure you created the RocketSystem instance after the scene and solarSystemData are initialized.

### Issue: Rocket doesn't appear
**Solution**: Check that `createRocket()` is called with valid position and planet group.

### Issue: Controls don't work
**Solution**: Verify `keys` object is being passed to `updateRocket(delta, keys)`.

### Issue: Tractor beam doesn't activate
**Solution**: Ensure rocket is in flight mode (not landed) and there's a valid target within range.

### Issue: Collision detection not working
**Solution**: Check that `solarSystemData` is properly populated with mesh references.

## Notes

- Keep the `keys` object accessible to RocketSystem methods
- The `infoElement` reference is used for status messages
- RocketSystem maintains its own state - no need to sync with external variables
- Camera updates still need to access rocketSystem properties for positioning
