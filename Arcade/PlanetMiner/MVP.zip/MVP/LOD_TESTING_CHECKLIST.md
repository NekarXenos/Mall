# LOD System Testing Checklist

## Visual Tests

### Test 1: Initial Load
- [ ] Game loads without errors
- [ ] First planet appears with high detail voxel terrain
- [ ] Other planets appear with medium detail (textured spheres)
- [ ] Console shows "LOD system initialized"

### Test 2: Character Mode Movement
- [ ] Walk around on first planet - high LOD maintained
- [ ] Use M key to teleport to next planet system
- [ ] Previous planet should switch to medium LOD
- [ ] Current planet should be high LOD
- [ ] Planets behind sun should be low LOD (icosahedrons)

### Test 3: Rocket Mode
- [ ] Press F to enter rocket
- [ ] Planet under rocket should be high LOD
- [ ] Fly toward another planet
- [ ] As you approach, target planet switches to high LOD
- [ ] Previous planet switches to medium LOD

### Test 4: Trajectory Intersection
- [ ] In rocket mode, enable trajectory line (W key to thrust)
- [ ] Planet that trajectory passes through should be high LOD
- [ ] Other planets should be medium or low LOD

### Test 5: Sun Occlusion (Character Mode)
- [ ] Exit rocket (F key when landed)
- [ ] Walk to position where sun is between you and other planets
- [ ] Planets on opposite side of sun should be low LOD (icosahedrons)
- [ ] Planets on same side as camera should be medium/high LOD

### Test 6: LOD Stats Display
- [ ] If debug mode is available, check LOD stats in HUD
- [ ] Stats should show reasonable distribution (e.g., "LOD: High=2 Med=4 Low=2")

## Performance Tests

### Test 7: Frame Rate
- [ ] Check FPS with all high LOD (hack the code temporarily)
- [ ] Compare with LOD system active
- [ ] Should see significant improvement with LOD enabled

### Test 8: LOD Switching Smoothness
- [ ] Fly between planets in rocket
- [ ] LOD switches should be quick (< 100ms perceived)
- [ ] No visible stuttering during LOD transitions

## Edge Cases

### Test 9: Multiple Moons
- [ ] Visit planet with multiple moons
- [ ] All moons in current system should be high LOD
- [ ] Moons in other systems should follow same rules as planets

### Test 10: Rapid Camera Changes
- [ ] Press V to cycle camera modes rapidly
- [ ] Press Z to zoom in/out
- [ ] LOD system should remain stable

## Console Checks

Look for these in browser console:
- "LOD system initialized" - confirms initialization
- No errors about missing properties (systemIndex, bodyIndex, seed, etc.)
- No "undefined" or "null" errors in LOD updates

## Known Issues to Watch For

1. **Missing mesh parent**: If terrain doesn't show up, check that blackHoleBubble exists
2. **Duplicate terrain**: If terrain appears twice, LOD cache might not be working
3. **Performance regression**: If FPS drops, LOD updates might be too frequent
4. **LOD thrashing**: Rapid switching between LOD levels indicates threshold issues

## How to Test

1. Open `planetsMVPmodules.html` in a browser (Chrome recommended)
2. Open Developer Tools (F12) and check Console tab
3. Follow the test cases above
4. Note any issues or unexpected behavior

## Success Criteria

- ✅ All high priority bodies (character system, rocket system, trajectory) use high LOD
- ✅ Other visible bodies use medium LOD
- ✅ Occluded bodies use low LOD
- ✅ Frame rate improved vs. all-high-LOD scenario
- ✅ No visual artifacts or missing meshes
- ✅ Smooth gameplay experience maintained
