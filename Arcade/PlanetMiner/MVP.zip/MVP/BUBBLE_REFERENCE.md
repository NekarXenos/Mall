# Black Hole Bubble Visual Reference

## Bubble Parameters

### Size Calculation
- **Planets (Regular):** `bubbleSize = planetRadius × 0.2`
- **Planets (Gas Giants):** `bubbleSize = effectiveRadius × 0.2` (where effectiveRadius = planetRadius × 2)
- **Moons:** `bubbleSize = moonRadius × 0.2`

### Bubble Components

Each bubble consists of three visual elements:

1. **Black Hole Sphere**
   - Shader-based sphere with animated fresnel effect
   - Colors: Black → Orange → White → Orange → Black (gradient based on viewing angle)
   - Animated transparency waves
   - Size: bubbleSize (radius)

2. **Accretion Disk**
   - Ring-shaped disk in the orbital plane
   - Inner Radius: bubbleSize × 1.25
   - Outer Radius: bubbleSize × 3.125
   - Features: Noise-based texture, doppler shift, gravitational redshift
   - Rotates slowly over time

3. **Particle Jets**
   - 1000 particles per bubble
   - Jets emanate from poles (top and bottom)
   - Colors: Cold (blue/cyan) → Mid (white) → Hot (orange/red)
   - Animation: Particles flow from poles down to accretion disk

## Hierarchy Visualization

```
Scene
│
├─ Sun (basic mesh, no bubble)
│
├─ Planet 1 Group (orbital position)
│  │
│  ├─ Planet 1 Black Hole Bubble (20% of planet size)
│  │  ├─ Bubble Sphere (shader material)
│  │  ├─ Accretion Disk (shader material)
│  │  ├─ Particle Jets (points material)
│  │  ├─ Planet Mesh (solid surface)
│  │  ├─ Ocean Sphere (if applicable)
│  │  ├─ Atmosphere Sphere (if applicable)
│  │  ├─ Gas Sphere (if gas giant)
│  │  └─ Liquid Sphere (if gas giant)
│  │
│  ├─ Ring System Group (if applicable, NOT in bubble)
│  │  └─ Ring Meshes
│  │
│  ├─ Moon 1 Group (moon orbit position)
│  │  └─ Moon 1 Black Hole Bubble (20% of moon size)
│  │     ├─ Bubble Sphere
│  │     ├─ Accretion Disk
│  │     ├─ Particle Jets
│  │     └─ Moon Mesh
│  │
│  └─ Moon 2 Group (moon orbit position)
│     └─ Moon 2 Black Hole Bubble (20% of moon size)
│        ├─ Bubble Sphere
│        ├─ Accretion Disk
│        ├─ Particle Jets
│        └─ Moon Mesh
│
├─ Planet 2 Group (orbital position)
│  ├─ Planet 2 Black Hole Bubble
│  │  └─ ...
│  └─ ...
│
└─ ...
```

## Example Sizes

For a planet with radius 100:
- Regular Planet Bubble: 20 units radius
  - Accretion Disk Inner: 25 units
  - Accretion Disk Outer: 62.5 units
  
For a gas giant with radius 100 (effectiveRadius 200):
- Gas Giant Bubble: 40 units radius
  - Accretion Disk Inner: 50 units
  - Accretion Disk Outer: 125 units

For a moon with radius 30:
- Moon Bubble: 6 units radius
  - Accretion Disk Inner: 7.5 units
  - Accretion Disk Outer: 18.75 units

## Animation Updates

Every frame (in `animate()` function):
```javascript
allBlackHoleBubbles.forEach(bubble => {
    updateBlackHoleBubble(bubble, delta, camera);
});
```

This updates:
- `uTime` uniform for bubble shader (wave animations)
- `time` uniform for accretion disk shader (texture animation)
- Disk rotation: `disk.rotation.z += deltaTime * 0.05`
- Particle jet animation uniforms

## Explosion Behavior

When `explodeCelestialBody(bodyData)` is called:

**REMOVED:**
- ❌ Planet/Moon mesh
- ❌ Ocean/Water sphere
- ❌ Atmosphere sphere
- ❌ Gas sphere
- ❌ Liquid sphere

**PRESERVED:**
- ✅ Black hole bubble (sphere, disk, jets)
- ✅ Ring systems
- ✅ Moon orbits (for planets)
- ✅ Orbital trajectory
- ✅ Gravitational effects
- ✅ Rocket (completely safe)

## Result After Explosion

After explosion, only these elements remain visible:
1. The animated black hole bubble (sphere)
2. The rotating accretion disk
3. The particle jets
4. Any rings the body had
5. Any moons orbiting the body (for planets)

The effect creates a "hollow" celestial body with just the black hole core remaining.
