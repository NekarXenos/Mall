# Rocket System Module - Extraction Summary

## Overview
The Rocket System has been successfully extracted from `pMain.js` into a dedicated module: `pRocketSystem.js`

## Module: `pRocketSystem.js`

### Class: `RocketSystem`

#### Constructor Parameters
- `scene` - Three.js scene reference
- `solarSystemData` - Array of planetary data
- `sun` - Sun mesh reference
- `infoElement` - UI info element for status messages

#### Key Features Extracted

##### 1. Rocket Physics
- **Gravity Calculation**: Handles gravity from all celestial bodies (sun, planets, moons)
- **Velocity Management**: Tracks and updates rocket velocity with proper physics
- **Anti-tunneling**: Uses segment-sphere intersection for collision prevention
- **Exploded Body Handling**: Switches gravity source to black hole bubbles for destroyed planets

##### 2. Rocket Controls
- **Yaw Control (A/D keys)**: Turn left/right in orbital plane
- **RCS Thrusters (Q/E keys)**: Strafe left/right
- **Main Thrust (W key)**: Forward acceleration with boost mode (Shift)
- **Brake System (X key)**: Velocity reduction or orbital sync (Shift+X)
- **Visual Feedback**: Plume effects change color/size based on thrust mode

##### 3. Launch Assist System
- **Auto-boost**: Automatic acceleration when taking off from a body
- **Grace Period**: Temporary collision immunity after takeoff
- **Radial Push**: Ensures rocket clears the surface before collisions resume
- **Configurable Parameters**: 
  - `LAUNCH_ASSIST_TARGET_RADIAL_SPEED`: Target outward speed
  - `LAUNCH_ASSIST_ACCEL`: Acceleration magnitude
  - `LAUNCH_ASSIST_GRACE_TIME`: Collision immunity duration
  - `LAUNCH_ASSIST_CLEARANCE`: Distance threshold for completion

##### 4. Takeoff/Landing System
- **Takeoff Logic**: Detaches from body, resets transforms, enables launch assist
- **Landing Detection**: Anti-tunneling collision detection with all bodies
- **Surface Alignment**: Rocket aligns to local surface normal
- **Parent Management**: Switches between scene and body mesh parenting
- **Forced Landing**: Automatic landing on collision

##### 5. Tractor Beam (Landing Autopilot)
- **Target Acquisition**: Finds and locks onto closest body within range
- **Approach Mode**: Halves distance to target every second
- **Landing Mode**: Gentle descent when close to surface
- **Velocity Matching**: Syncs with target body's orbital velocity
- **Rotation Sync**: Points rocket toward target automatically
- **Visual Feedback**: Cyan highlight ring and special plume colors
- **Auto-landing**: Completes landing when velocity and distance thresholds met

##### 6. Trajectory Prediction
- **Physics Simulation**: Predicts 500 steps ahead using actual gravity
- **Moon Gravity**: Includes moons when near planets
- **Thrust Prediction**: Factors in current thrust input
- **Visual Line**: Green line showing predicted path
- **Orbital Plane Constraint**: Trajectory stays on XZ plane

##### 7. Orbital Velocity Sync
- **Planet Sync**: Matches velocity with planetary orbital motion
- **Moon Sync**: Combines moon orbital velocity + planet orbital velocity
- **Automatic Calculation**: Uses G_CONSTANT and body parameters

#### Public Methods

##### Rocket Creation
- `createRocket(initialPosition, launchPlanetGroup)` - Creates rocket mesh with all components
- `createDirectionArrow(rocket)` - Adds directional indicator arrow

##### Control Methods
- `switchToRocket()` - Activates rocket control mode
- `switchToCharacter()` - Deactivates rocket control mode
- `updateRocket(delta, keys)` - Main update loop for physics and controls
- `updateTrajectory(delta, keys)` - Updates trajectory prediction line

##### Tractor Beam
- `toggleTractorBeam(rocketWorldPos)` - Activates/deactivates autopilot
- `updateTractorBeam(delta, rocketWorldPos)` - Updates autopilot behavior
- `findClosestBody(position, maxDistance)` - Locates nearest valid target

##### Utility Methods
- `getRocketWorldPosition()` - Returns world position
- `getRocketWorldQuat()` - Returns world quaternion
- `getRocketForwardWS()` - Forward direction in world space
- `getRocketRightWS()` - Right direction in world space
- `getRocketLeftWS()` - Left direction in world space
- `isLanded()` - Checks if rocket is on a surface
- `getState()` - Returns state for saving
- `dispose()` - Cleanup resources

#### Private/Helper Methods
- `calculateRocketGravity(rocketWorldPos)` - Computes total gravity force
- `updateLaunchAssist(delta, rocketWorldPos)` - Launch assist update loop
- `handleRocketControls(delta, keys, rocketWorldPos)` - Processes all control inputs
- `handleThrustControl(delta, keys, rocketWorldPos)` - Manages thrust and takeoff
- `handleTakeoff(rocketWorldPos)` - Detaches rocket from surface
- `handleBrakeControl(keys, rocketWorldPos)` - Processes brake/sync commands
- `syncOrbitalVelocity(rocketWorldPos)` - Matches closest body's orbital velocity
- `pointRocketToward(targetDirection, delta, speedMultiplier)` - Aims rocket at direction
- `calculateBodyVelocity(bodyData, bodyWorldPos)` - Computes body orbital velocity
- `updateTractorBeamLanding(...)` - Landing phase of autopilot
- `updateTractorBeamApproach(...)` - Approach phase of autopilot
- `performAutoLanding(rocketWorldPos)` - Completes automatic landing
- `checkRocketCollisions(rocketWorldPos, prevPos)` - Collision detection
- `landRocketOnBody(bodyMesh, bodyData, rocketWorldPos)` - Performs landing sequence

#### State Properties
- **Rocket Objects**: rocketObject, rocketPivot, rocketPlume, trajectoryLine
- **Rocket State**: isInRocket, rocketVelocity, rocketYaw
- **Launch Assist**: launchAssistActive, launchAssistGraceLeft, etc.
- **Tractor Beam**: tractorBeamActive, tractorBeamTarget, tractorBeamLandingMode
- **Previous Position**: prevRocketWorldPos (for anti-tunneling)

## Integration Points

### Dependencies
```javascript
import * as THREE from 'three';
import { /* constants */ } from './pConstants.js';
import { segmentIntersectsSphere, calculateTrajectoryGravity } from './pPhysics.js';
```

### Required Constants
- Rocket dimensions and thrust values
- Launch assist parameters
- Tractor beam parameters
- Physics constants (G_CONSTANT, SUN_RADIUS)

### Physics Module Integration
- Uses `segmentIntersectsSphere()` for anti-tunneling collision detection
- Uses `calculateTrajectoryGravity()` for trajectory prediction

## Usage Example

```javascript
import { RocketSystem } from './pRocketSystem.js';

// Create rocket system
const rocketSystem = new RocketSystem(scene, solarSystemData, sun, infoElement);

// Create rocket at initial position
const { rocketObject, rocketPivot, rocketPlume } = rocketSystem.createRocket(
    initialPosition,
    launchPlanetGroup
);

// In update loop
if (rocketSystem.isInRocket) {
    rocketSystem.updateRocket(delta, keys);
    rocketSystem.updateTrajectory(delta, keys);
}

// Toggle controls
if (keys['F']) {
    if (rocketSystem.isInRocket) {
        rocketSystem.switchToCharacter();
    } else {
        rocketSystem.switchToRocket();
    }
}

// Toggle tractor beam
if (keys['O']) {
    const rocketPos = rocketSystem.getRocketWorldPosition();
    rocketSystem.toggleTractorBeam(rocketPos);
}
```

## Benefits of Modularization

1. **Separation of Concerns**: All rocket logic isolated from character/camera systems
2. **Easier Testing**: Can test rocket physics independently
3. **Improved Maintainability**: Changes to rocket behavior don't affect other systems
4. **Better Readability**: Clear API with documented methods
5. **Reusability**: Rocket system can be used in other projects
6. **State Management**: All rocket state centralized in one class

## Next Steps

To complete the integration with `pMain.js`:

1. Import the RocketSystem class
2. Replace all rocket-related variables and functions with RocketSystem instance
3. Update event handlers to call RocketSystem methods
4. Test all rocket functionality (thrust, landing, tractor beam, etc.)

## Notes

- The module maintains full compatibility with existing code structure
- All original functionality has been preserved
- Visual feedback systems (plumes, trajectory lines) are included
- Launch assist and tractor beam are fully integrated
- The module handles both landed and flying states correctly
