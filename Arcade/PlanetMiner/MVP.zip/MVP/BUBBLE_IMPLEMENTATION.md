# Black Hole Bubble Implementation

## Overview
This document describes the implementation of black hole bubbles as parent containers for all planets and moons in the solar system.

## Changes Made

### 1. Import Black Hole Bubble Module
- Added import for `createBlackHoleBubble` and `updateBlackHoleBubble` from `pBlackHoleBubble.js`

### 2. Black Hole Bubble Creation

#### For Planets
- Each planet now has a black hole bubble created at **20% of its effective radius**
- For gas giants, the bubble size is based on `effectiveRadius` (which is 2x the solid radius)
- For regular planets, the bubble size is based on the normal radius
- The bubble is added to the `planetGroup` and stored in `planetData.blackHoleBubble`

#### For Moons
- Each moon has a black hole bubble created at **20% of its radius**
- The bubble is added to the `moonGroup` and stored in `moonData.blackHoleBubble`

### 3. Scene Hierarchy
The new hierarchy structure is:
```
scene
└── planetGroup (positioned at orbital distance)
    └── planetBubble (black hole bubble)
        ├── planet mesh
        ├── oceanSphere (if applicable)
        ├── atmosphereSphere (if applicable)
        ├── gasSphere (if gas giant)
        └── liquidSphere (if gas giant)
    └── moonGroup (positioned at moon orbit)
        └── moonBubble (black hole bubble)
            └── moon mesh
```

### 4. Animation Updates
- All black hole bubbles are stored in the `allBlackHoleBubbles` array
- Each frame, all bubbles are updated with `updateBlackHoleBubble(bubble, delta, camera)`
- This animates the bubble shaders, accretion disk rotation, and particle jets

### 5. Explosion Support Functions

Two helper functions were added to support future planet explosion mechanics:

#### `removeCelestialBodyVisuals(bodyData)`
Safely removes all visual elements of a planet/moon:
- Main mesh (planet/moon surface)
- Atmosphere sphere
- Water/ocean sphere
- Gas sphere (for gas giants)
- Liquid sphere (for gas giants)

**Important:** This function preserves:
- The black hole bubble (remains intact)
- Ring systems (if any)
- Moon systems (if any)
- The rocket (managed separately)

#### `explodeCelestialBody(bodyData)`
Triggers an explosion for a planet/moon:
- Currently calls `removeCelestialBodyVisuals()`
- Logs the explosion to console
- **TODO:** Add particle explosion effects similar to PlanetJump26.html

## Trajectory Preservation
The orbital trajectories are preserved because:
1. The `planetGroup` still handles the orbital positioning
2. The bubble is a child of `planetGroup`, so it inherits the orbital motion
3. The planet/moon meshes are children of the bubble, maintaining proper transform hierarchy

## Rocket Safety
The rocket is completely safe from explosions because:
1. The rocket is managed in a separate hierarchy (either in `scene` or attached to a surface)
2. The explosion functions only remove visual meshes that are children of the bubble
3. The bubble itself is never removed, providing a persistent gravitational reference point

## Future Explosion Implementation
To add explosion effects similar to PlanetJump26.html:

1. **Create explosion particles:** Generate particle systems at the planet/moon position
2. **Animate explosion:** Expand particles outward with appropriate physics
3. **Color effects:** Use the original planet color for explosion particles
4. **Timing:** Call `removeCelestialBodyVisuals()` after a short delay to remove the surface
5. **Sound effects:** Add audio feedback for explosions (optional)

Example usage:
```javascript
// To explode a planet (e.g., Planet 1)
explodeCelestialBody(solarSystemData[0]);

// To explode a moon (e.g., Moon 1-A of Planet 1)
explodeCelestialBody(solarSystemData[0].moons[0]);
```

## Visual Result
Each celestial body now has:
- A black hole bubble with animated fresnel shading (orange/white/black waves)
- An accretion disk rotating slowly around the bubble
- Particle jets emanating from the poles
- The original planet/moon surface and atmosphere visible through the bubble

The bubbles are small enough (20% scale) to be subtle but visible, creating an interesting visual effect without overwhelming the scene.

## Performance Considerations
- Each bubble contains ~1000 particle jets
- Shader calculations run on GPU for efficient rendering
- Animation updates are lightweight (just uniform value increments)
- Total overhead: ~2 shader materials and 1 particle system per celestial body
